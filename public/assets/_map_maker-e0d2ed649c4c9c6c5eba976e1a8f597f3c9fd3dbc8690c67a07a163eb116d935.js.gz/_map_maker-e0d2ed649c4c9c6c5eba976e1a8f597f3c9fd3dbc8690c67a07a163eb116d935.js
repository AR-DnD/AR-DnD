/* globals $ */


$(document).on('turbolinks:load', function () {
  var gridDimension = 6;
  var grid = new Array(gridDimension)
  for (var i = 0; i < gridDimension; i++){
    grid[i] = new Array(gridDimension).fill(null)
  }

  if ($('#map_data').val()) {
    var savedState = JSON.parse($('#map_data').val())
    for (var i = 0; i < savedState.length; i++) {
      for (var j = 0; j < savedState[i].length; j++) {
        var stringID = String(i) + '-' + String(j)
        var currGridCoord = $('#' + stringID)
        if (savedState[i][j]) {
          var currGridElement = savedState[i][j].split('-')
          currGridCoord.css('background-image', 'url(/assets/' + currGridElement[1] + '.png)')
          if (currGridElement[0] === 'char') {
            currGridCoord.empty()
            $('<p>' + currGridElement[2] + '</p>').appendTo(currGridCoord)
          }
        }
      }
    }
    grid = savedState
  } else {
      $('#map_data').val(JSON.stringify(grid))
  }
  var currElement = 'obj-Tree'

  $('input').on('click', function () {
    $('#log').html($('input:checked').val() + ' is checked!')
  })

  $('.mapElement').on('click', function () {
    currElement = $(this).attr('id')
    $('.selected-text').html(currElement.split('-')[1])
    $('#selected-image').css('background-image', 'url(/assets/' + currElement.split('-')[1] + '.png)')
  })

  $('.btn-mapgrid').unbind('click').on('click', function (e) {
    e.stopPropagation()
    e.preventDefault()
    if ($('#show_map-flag').length > 0) {
      return
    }
    var currData = currElement.split('-')
    $(this).html('')
    if (currData[0] === 'char') {
      $(this).empty()
      $('<p>' + currData[2] + '</p>').appendTo($(this))
      for (var i = 0; i < grid.length; i++) {
        for (var j = 0; j < grid.length; j++) {
          if (grid[i][j] === currElement) {
            grid[i][j] = null
            var stringID = String(i) + '-' + String(j)
            var currGridCoord = $('#' + stringID)
            currGridCoord.css('background-image', '')
            currGridCoord.html('')
          }
        }
      }
    }
    var coords = $(this).attr('id').split('-')
    var rowNum = coords[0]
    var colNum = coords[1]
    rowNum = parseInt(rowNum)
    colNum = parseInt(colNum)
    if (currData[1] === 'Nil') {
      grid[rowNum][colNum] = null
      $(this).css('background-image', '')
      $(this).html('')
      $(this).empty()
    } else {
      grid[rowNum][colNum] = currElement
      var imageUrlString = '/assets/' + currData[1] + '.png'
      $(this).css('background-image', 'url(' + imageUrlString + ')')
    }
    $('#map_data').val(JSON.stringify(grid))
  })

  $('#map_name').on('keyup', function () {
    if (!$(this).val() || !$('#map_story').val()) {
      $("input[type='submit'][name='commit'][value='CREATE MAP']").prop('disabled', true)
      $("input[type='submit'][name='commit'][value='UPDATE MAP']").prop('disabled', true)
      console.log("DONT")
    } else {
      $("input[type='submit'][name='commit'][value='CREATE MAP']").prop('disabled', false)
      $("input[type='submit'][name='commit'][value='UPDATE MAP']").prop('disabled', false)
    }
  })

  $('#map_story').on('keyup', function () {
    if (!$('#map_name').val() || !$(this).val()) {
      $("input[type='submit'][name='commit'][value='CREATE MAP']").prop('disabled', true)
      $("input[type='submit'][name='commit'][value='UPDATE MAP']").prop('disabled', true)
      console.log("DONT")
    } else {
      $("input[type='submit'][name='commit'][value='CREATE MAP']").prop('disabled', false)
      $("input[type='submit'][name='commit'][value='UPDATE MAP']").prop('disabled', false)
    }
  })
})
;
